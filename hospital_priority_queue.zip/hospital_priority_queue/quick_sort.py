"""Part (b2): Quick Sort (Lomuto partition, last element as pivot)."""
cnt = {"comp": 0, "swap": 0, "depth": 0}

def quick_sort(a, lo, hi, d=0):
    if lo >= hi: return
    cnt["depth"] = max(cnt["depth"], d)
    pivot = a[hi]; i = lo - 1
    for j in range(lo, hi):
        cnt["comp"] += 1
        if a[j] <= pivot:
            i += 1
            if i != j:
                a[i], a[j] = a[j], a[i]; cnt["swap"] += 1
    if i + 1 != hi:
        a[i+1], a[hi] = a[hi], a[i+1]; cnt["swap"] += 1
    print(f"{'  '*d}pivot={pivot:>2} on indices [{lo}..{hi}] -> pivot at index {i+1}: {a}")
    quick_sort(a, lo, i, d + 1)
    quick_sort(a, i + 2, hi, d + 1)

if __name__ == "__main__":
    scores = [45, 72, 30, 90, 65, 50, 85]
    a = scores[:]
    print("Input:", a, "\n")
    quick_sort(a, 0, len(a) - 1)
    print("\nFinal sorted (ascending):", a)
    print("Priority order (descending):", a[::-1])
    print(f"TOTAL comparisons: {cnt['comp']} | TOTAL swaps: {cnt['swap']} | max recursion depth: {cnt['depth']}")
