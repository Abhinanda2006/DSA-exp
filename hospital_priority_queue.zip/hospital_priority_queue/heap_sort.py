"""Part (b1): Heap Sort with intermediate steps."""
import math
cnt = {"comp": 0, "swap": 0}

def sift_down(a, n, i):
    while True:
        l, r, m = 2*i+1, 2*i+2, i
        if l < n:
            cnt["comp"] += 1
            if a[l] > a[m]: m = l
        if r < n:
            cnt["comp"] += 1
            if a[r] > a[m]: m = r
        if m == i: return
        a[i], a[m] = a[m], a[i]
        cnt["swap"] += 1
        i = m

def heap_sort(arr):
    a = arr[:]; n = len(a)
    print("Input:", a)
    print("\n-- Phase 1: Build max heap (bottom-up) --")
    for i in range(n // 2 - 1, -1, -1):
        sift_down(a, n, i)
        print(f"Heapify at index {i}: {a}")
    print("Max heap built:", a, "| height =", math.floor(math.log2(n)))
    build = dict(cnt)
    print(f"Build phase -> comparisons: {build['comp']}, swaps: {build['swap']}")
    print("\n-- Phase 2: Repeatedly move root to the end --")
    for end in range(n - 1, 0, -1):
        a[0], a[end] = a[end], a[0]
        cnt["swap"] += 1
        sift_down(a, end, 0)
        print(f"Place {a[end]:>2} at index {end}: {a}")
    print(f"Extraction phase -> comparisons: {cnt['comp']-build['comp']}, swaps: {cnt['swap']-build['swap']}")
    return a

if __name__ == "__main__":
    scores = [45, 72, 30, 90, 65, 50, 85]
    res = heap_sort(scores)
    print("\nFinal sorted (ascending):", res)
    print("Priority order (descending):", res[::-1])
    print(f"TOTAL comparisons: {cnt['comp']} | TOTAL swaps: {cnt['swap']}")
