# Hospital Priority Queue: Max Heap, Heap Sort and Quick Sort

Patient severity scores: `45, 72, 30, 90, 65, 50, 85` (higher score = higher priority)

Folder contents:
- `max_heap.py`, `heap_sort.py`, `quick_sort.py`: the programs
- `outputs/`: the recorded output of each program

Run with `python3 max_heap.py`, `python3 heap_sort.py`, `python3 quick_sort.py`.

---

## a) Max Heap: heap after each insertion

| Step | Insert | Heap (array form) | Comparisons | Swaps |
|---|---|---|---|---|
| 1 | 45 | [45] | 0 | 0 |
| 2 | 72 | [72, 45] | 1 | 1 |
| 3 | 30 | [72, 45, 30] | 1 | 0 |
| 4 | 90 | [90, 72, 30, 45] | 2 | 2 |
| 5 | 65 | [90, 72, 30, 45, 65] | 1 | 0 |
| 6 | 50 | [90, 72, 50, 45, 65, 30] | 2 | 1 |
| 7 | 85 | [90, 72, 85, 45, 65, 30, 50] | 2 | 1 |

Final heap:
```
        90
      /    \
    72      85
   /  \    /  \
  45  65  30  50
```
- Height = floor(log2 7) = **2**
- Total for 7 insertions: **9 comparisons, 5 swaps**
- Highest-priority patient (peek): **90**
- Serving order by repeated extract-max: 90, 85, 72, 65, 50, 45, 30

---

## b) Heap Sort and Quick Sort

### b1) Heap Sort
Input: `[45, 72, 30, 90, 65, 50, 85]`

Phase 1, build the max heap (bottom-up):
- Heapify at index 2: `[45, 72, 85, 90, 65, 50, 30]`
- Heapify at index 1: `[45, 90, 85, 72, 65, 50, 30]`
- Heapify at index 0: `[90, 72, 85, 45, 65, 50, 30]`
- Build cost: 8 comparisons, 4 swaps

Phase 2, move the root to the end and restore the heap:
- Place 90 at index 6: `[85, 72, 50, 45, 65, 30, 90]`
- Place 85 at index 5: `[72, 65, 50, 45, 30, 85, 90]`
- Place 72 at index 4: `[65, 45, 50, 30, 72, 85, 90]`
- Place 65 at index 3: `[50, 45, 30, 65, 72, 85, 90]`
- Place 50 at index 2: `[45, 30, 50, 65, 72, 85, 90]`
- Place 45 at index 1: `[30, 45, 50, 65, 72, 85, 90]`
- Extraction cost: 13 comparisons, 14 swaps

**Final output:** `[30, 45, 50, 65, 72, 85, 90]`. Reversed, this is the priority order 90, 85, 72, 65, 50, 45, 30.
**Total: 21 comparisons, 18 swaps.**

### b2) Quick Sort (Lomuto partition, last element as pivot)
Input: `[45, 72, 30, 90, 65, 50, 85]`

| Partition | Pivot | Range | Array after partition |
|---|---|---|---|
| 1 | 85 | [0..6] | [45, 72, 30, 65, 50, 85, 90] |
| 2 | 50 | [0..4] | [45, 30, 50, 65, 72, 85, 90] |
| 3 | 30 | [0..1] | [30, 45, 50, 65, 72, 85, 90] |
| 4 | 72 | [3..4] | [30, 45, 50, 65, 72, 85, 90] |

**Final output:** `[30, 45, 50, 65, 72, 85, 90]`. Reversed, this is the priority order 90, 85, 72, 65, 50, 45, 30.
**Total: 12 comparisons, 6 swaps, maximum recursion depth 2.**

---

## c) Analysis

| Criterion | Max Heap / Heap Sort | Quick Sort |
|---|---|---|
| **Structure and height** | A complete binary tree stored in an array (parent of i is (i-1)/2, children are 2i+1 and 2i+2). It is always balanced, so height = floor(log2 n) (2 here), regardless of the input order. It persists between operations. | No persistent structure. Only a recursion tree exists, and its shape depends on pivot choice (depth 2 here). Depth is O(log n) on average but O(n) in the worst case (e.g. already sorted data with a last-element pivot). |
| **Comparisons / swaps observed** | Insertion only: 9 comparisons, 5 swaps. Full Heap Sort: 21 comparisons, 18 swaps (build 8/4, extraction 13/14). | 12 comparisons, 6 swaps. |
| **Time complexity** | Insert O(log n); peek highest priority O(1); extract-max O(log n); build heap O(n). Heap Sort is O(n log n) in best, average and worst cases. | Best and average O(n log n); worst case O(n²). Every new patient requires re-sorting (O(n log n)), or an O(n) insertion into an already sorted array. |
| **Space** | O(1) extra space (in place); the heap is just an array of n elements. | O(log n) recursion stack on average; O(n) in the worst case. Also in place for the array itself. |

Observation: on this small input Quick Sort used fewer comparisons and swaps than a full Heap Sort, because Heap Sort has a larger constant factor. But the hospital does not need a fully sorted list. It needs the maximum quickly, and that job is done by the heap alone (9 comparisons and 5 swaps to hold all 7 patients).

### Conclusion: which approach is more suitable?
**The Max Heap (priority queue) is the more suitable approach** for a hospital that continuously admits patients and needs the highest-priority patient immediately.

1. **Fast insertion:** a new patient is added in O(log n). Quick Sort would need a full re-sort or an O(n) insertion each time.
2. **Immediate access:** the most critical patient is always at the root, found in O(1) and removed in O(log n).
3. **Predictable performance:** heap operations are guaranteed O(log n), while Quick Sort can degrade to O(n²). That is unacceptable when delays affect critical patients.
4. **Low memory:** the heap needs only an array and no recursion stack.
5. **Right tool:** sorting is a batch operation. Quick Sort or Heap Sort is appropriate for producing a one-off sorted report, but a live triage queue only needs the maximum at any moment.
