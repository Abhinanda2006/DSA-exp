"""Part (a): Max Heap for hospital patient severity scores."""
import math

class MaxHeap:
    def __init__(self):
        self.a = []
        self.comparisons = 0
        self.swaps = 0

    def insert(self, x):
        self.a.append(x)
        i = len(self.a) - 1
        while i > 0:
            p = (i - 1) // 2
            self.comparisons += 1
            if self.a[i] > self.a[p]:
                self.a[i], self.a[p] = self.a[p], self.a[i]
                self.swaps += 1
                i = p
            else:
                break

    def peek(self):
        return self.a[0]

    def extract_max(self):
        top, last = self.a[0], self.a.pop()
        if self.a:
            self.a[0] = last
            i, n = 0, len(self.a)
            while True:
                l, r, m = 2*i+1, 2*i+2, i
                if l < n:
                    self.comparisons += 1
                    if self.a[l] > self.a[m]: m = l
                if r < n:
                    self.comparisons += 1
                    if self.a[r] > self.a[m]: m = r
                if m == i: break
                self.a[i], self.a[m] = self.a[m], self.a[i]
                self.swaps += 1
                i = m
        return top

def print_tree(a):
    n = len(a); level = 0; i = 0
    while i < n:
        w = 2 ** level
        print(f"  Level {level}: {a[i:i+w]}")
        i += w; level += 1

if __name__ == "__main__":
    scores = [45, 72, 30, 90, 65, 50, 85]
    print("Patient severity scores:", scores)
    print("\n=== Max Heap: heap after each insertion ===")
    h = MaxHeap()
    for s in scores:
        c0, s0 = h.comparisons, h.swaps
        h.insert(s)
        print(f"Insert {s:>2} -> {h.a}   (comparisons: {h.comparisons-c0}, swaps: {h.swaps-s0})")
    print("\nFinal heap by level:")
    print_tree(h.a)
    print("\nHeap size:", len(h.a), "| Height:", math.floor(math.log2(len(h.a))))
    print("Total comparisons:", h.comparisons, "| Total swaps:", h.swaps)
    print("Highest-priority patient (peek):", h.peek())
    print("\nServing order (repeated extract-max):")
    order = []
    while h.a:
        order.append(h.extract_max())
    print(" ", order)
