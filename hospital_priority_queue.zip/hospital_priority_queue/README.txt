Hospital Priority Queue assignment
Scores: 45, 72, 30, 90, 65, 50, 85

REPORT.md      - full write-up: parts (a), (b), (c) and final conclusion
max_heap.py    - part (a)
heap_sort.py   - part (b), Heap Sort
quick_sort.py  - part (b), Quick Sort
outputs/       - recorded program outputs

Run: python3 max_heap.py ; python3 heap_sort.py ; python3 quick_sort.py   (Python 3, no libraries needed)
